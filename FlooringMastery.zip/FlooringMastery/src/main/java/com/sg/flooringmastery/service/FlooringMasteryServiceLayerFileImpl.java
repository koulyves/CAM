/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.sg.flooringmastery.service;

import com.sg.flooringmastery.dao.FlooringMasteryOrderDao;
import com.sg.flooringmastery.dao.FlooringMasteryPersistenceException;
import com.sg.flooringmastery.dao.FlooringMasteryProductDao;
import com.sg.flooringmastery.dao.FlooringMasteryStateTaxDao;
import com.sg.flooringmastery.dto.Order;
import java.time.LocalDate;
import java.util.List;

/**
 *
 * @author n0200797
 */
public class FlooringMasteryServiceLayerFileImpl implements FlooringMasteryServiceLayer {

    FlooringMasteryOrderDao orderDao;
    FlooringMasteryProductDao productDao;
    FlooringMasteryStateTaxDao stateTaxDao;

    public FlooringMasteryServiceLayerFileImpl(FlooringMasteryOrderDao orderDao,
            FlooringMasteryProductDao productDao, FlooringMasteryStateTaxDao stateTaxDao) {
        this.orderDao = orderDao;
        this.productDao = productDao;
        this.stateTaxDao = stateTaxDao;

    }
//******************************************************************************

    @Override
    public List<Order> getOrders(LocalDate date)
            throws NoOrderFoundException, FlooringMasteryPersistenceException {
        List<Order> allOrderByDate = orderDao.retrieveOrdersByDate(date);
        return allOrderByDate;
    }
//******************************************************************************

    @Override
    public Order createOrder(LocalDate date, Order order)
            throws NoOrderFoundException,
            FlooringMasteryPersistenceException,
            InvalidMoneyException {
        boolean isValid = false;
        

        if (stateTaxDao.getTax(order.getTaxRate().getStateName()) == null) {
            isValid = true;
            throw new FlooringMasteryPersistenceException("State Name Not Found");
        }

        if (productDao.getProduct(order.getProductType().getProductType()) == null) {
            isValid = true;
            throw new FlooringMasteryPersistenceException("Product Name NotFound");
        }

        if (isValid) {
            //order.setNumber(order.getNumber());
            order.setCustomerName(order.getCustomerName());
            order.setTaxRate(stateTaxDao.getTax(order.getTaxRate().getStateName()));

            order.setProductType(productDao.getProduct(order.getProductType().getProductType()));
            order.setArea(order.getArea());
            order.setMaterialCost(order.getMaterialCost());
            order.setLaborCost(order.getLaborCost());
            order.setTax(order.getTax());
            order.setTotal(order.getTotal());
        }
        return order;
    }

//****************************************************************************** 
    @Override
    public Order editOrder(LocalDate date, Order order) 
            throws NoOrderFoundException, 
            FlooringMasteryPersistenceException, 
            InvalidMoneyException {
        return orderDao.editOrder(date,order); 
    }
//******************************************************************************

    @Override
    public void removeOrder(LocalDate date, Order order) 
            throws NoOrderFoundException, 
            FlooringMasteryPersistenceException, 
            InvalidMoneyException {
            orderDao.removeOrder(date, order.getNumber());
    }
//******************************************************************************    

	@Override
	public Order getOrder(int ordernumber, LocalDate date) {
		return orderDao.getOrder(ordernumber, date);
	}
}
