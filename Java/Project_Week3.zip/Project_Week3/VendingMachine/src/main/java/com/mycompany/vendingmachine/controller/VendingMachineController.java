/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.mycompany.vendingmachine.controller;

import com.mycompany.vendingmachine.dao.VendingMachinePersistenceException;
import com.mycompany.vendingmachine.service.VendingMachineServiceLayer;
import com.mycompany.vendingmachine.ui.UserIO;
import com.mycompany.vendingmachine.ui.UserIOConsoleImpl;
import com.mycompany.vendingmachine.ui.VendingMachineView;
import java.math.BigDecimal;

/**
 *
 * @author n0200797
 */
public class VendingMachineController {
        private VendingMachineView view;
    private VendingMachineServiceLayer service;

    public VendingMachineController(VendingMachineServiceLayer service, VendingMachineView view) {
        this.service = service;
        this.view = view;
    }
//******************************************************************************    
    private UserIO io = new UserIOConsoleImpl();

    int menuSelection;

    public void run() {
        boolean keepGoing = true;
        try {
            while (keepGoing) {
                menuSelection = getMenuSelection();

                switch (menuSelection) {
                    case 1:
                        addToClientMoney();                        
                        break;
                    case 2:
                        
                        break;
                    case 3:
                        
                        break;
                    case 4:
                        keepGoing = false;
                        break;
                    default:
                        
                }

            }
            exitMessage();
        } catch (VendingMachinePersistenceException e) {
            view.displayErrorMessage(e.getMessage());

        }
    }
//***************************ADD MONEY *****************************************
BigDecimal clientMoney = BigDecimal.ZERO;
private void addToClientMoney(){
    BigDecimal moneyAdded;
    moneyAdded = view.clientMoney();
    clientMoney = clientMoney.add(moneyAdded);    
    
}
//******************************************************************************    
    private int getMenuSelection() throws VendingMachinePersistenceException {
        //view.logo();
        view.displayItemList(service.getInventory(), clientMoney);
        view.clientMoney();
        return view.displayAndGoToChoice();
//        return view.printMenuSelection();                
    }  
     
//******************************************************************************
    private void exitMessage() {
        view.displayExitBanner();
    }
//******************************************************************************    
    
}
