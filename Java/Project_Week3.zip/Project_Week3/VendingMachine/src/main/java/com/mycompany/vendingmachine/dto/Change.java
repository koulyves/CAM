/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.mycompany.vendingmachine.dto;

/**
 *
 * @author n0200797
 */
public class Change {
    private int pennies;
    private int quarters;
    private int dimes;
    private int nickels;

//Can also be my Total Money
//    private BigDecimal pennies;//Can also be my Total Money
//    private BigDecimal myQuarter = new BigDecimal(".25");
//    private BigDecimal myDime = new BigDecimal(".10");
//    private BigDecimal myNikel = new BigDecimal(".50");
//*******************PLACEHOLDER FOR MY CONSTRUCTOR*****************************
    public void calcChange() {
        int remainder;

        quarters = (pennies - (pennies % 25)) / 25;
        remainder = pennies % 25;
        pennies = remainder;
        
        dimes = (pennies - (pennies % 10)) / 10;
        remainder = pennies % 10;
        pennies = remainder;

        nickels = (pennies - (pennies % 5)) / 5;
        remainder = pennies % 5;
        pennies = remainder;

//        String Change = "Quarters" + Math.abs(quarters);
    }

//***********************MY METHOD**********************************************
    public void setPennies(int pennies) {
        this.pennies = pennies;
    }
//**********************MY GETTERS - NO SETTERS NEEDED**************************

    public int getQuarters() {
        return quarters;
    }

    public int getDimes() {
        return dimes;
    }

    public int getPennies() {
        return pennies;
    }

    public int getNickels() {
        return nickels;
    }

}
