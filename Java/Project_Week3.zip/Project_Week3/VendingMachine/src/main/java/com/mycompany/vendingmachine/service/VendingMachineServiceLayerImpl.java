/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.mycompany.vendingmachine.service;

import com.mycompany.vendingmachine.dao.VendingMachineDao;
import com.mycompany.vendingmachine.dao.VendingMachineDaoFileImpl;
import com.mycompany.vendingmachine.dao.VendingMachinePersistenceException;
import com.mycompany.vendingmachine.dto.Item;
import java.io.FileNotFoundException;
import java.math.BigDecimal;
import java.util.List;

/**
 *
 * @author n0200797
 */
public class VendingMachineServiceLayerImpl implements VendingMachineServiceLayer {
    //VendingMachineDaoFileImpl dao;
    VendingMachineDao dao;
    

    public VendingMachineServiceLayerImpl(VendingMachineDao dao) {
        this.dao = dao;
    }
//************************ABSTRACT SERVICE LAYER METHODS************************

//    @Override
//    public void loadInventory() throws FileNotFoundException {
//        dao.loadItem();
//    }

    @Override
    public List<Item> getInventory() throws
            VendingMachinePersistenceException {
        return dao.getAllItems();
    }

    @Override
    public void validateMoney(BigDecimal clientMoney) throws InvalidClientMoneyException {
        //VALIDATE IF USER ENTERED MONEY WITH 2 DECIMAL
        if (clientMoney.scale() != 2) {
            throw new InvalidClientMoneyException(clientMoney);
        }//VALIDATE A POSITIVE MONEY IS ENTERED
        else if(clientMoney.compareTo(new BigDecimal("0")) != 1){
            throw new InvalidClientMoneyException(clientMoney);
        }//VALIDATE USER DID NOT ENTER PENNIES
        else if(!clientMoney.remainder(new BigDecimal(".05")).setScale(2).equals(new BigDecimal("0.00"))){
            throw new InvalidClientMoneyException(clientMoney);
        }
    }

    @Override
    public void validateInventory(int itemId) throws NoItemInventoryException {
//        Item userSelection = dao.getAnItem(itemId)
//        if (dao.getAnItem(userSelection).getQuantity() < 1) {
//            throw new InsufficientFundsException();
//        }
    }
}

//************************PRODUCT AVAILABLE*************************************    

