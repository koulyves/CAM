/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.mycompany.vendingmachine.dao;

import com.mycompany.vendingmachine.dto.Item;
import java.util.List;
import org.junit.After;
import org.junit.AfterClass;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Test;
import static org.junit.Assert.*;

/**
 *
 * @author n0200797
 */
public class VendingMachineDaoTest {
    
    private VendingMachineDao dao = new VendingMachineDaoFileImpl();
    
    public VendingMachineDaoTest() {
    }
    
    @BeforeClass
    public static void setUpClass() {
    }
    
    @AfterClass
    public static void tearDownClass() {
    }
    
    @Before
    public void setUp() throws Exception{
        //Set the Dao to a known Good State
        List<Item> itemList = dao.getAllItems();
        for (Item item : itemList){
            //Insert code here
        }
    }
    
    @After
    public void tearDown() {
    }

    /**
     * Test of getAllItems method, of class VendingMachineDao.
     */
    @Test
    public void testGetAllItems() throws Exception {
    }

    /**
     * Test of getAnItem method, of class VendingMachineDao.
     */
    @Test
    public void testGetAnItem() throws Exception {
    }

    /**
     * Test of updateItemQuantity method, of class VendingMachineDao.
     */
    @Test
    public void testUpdateItemQuantity() throws Exception {
    }

    /**
     * Test of saveItemsToFile method, of class VendingMachineDao.
     */
    @Test
    public void testSaveItemsToFile() throws Exception {
    }

}
