/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.mycompany.vendingmachine.service;

import com.mycompany.vendingmachine.dao.VendingMachineDao;
import com.mycompany.vendingmachine.dao.VendingMachineDaoStubImpl;
import com.mycompany.vendingmachine.dao.VendingMachinePersistenceException;
import com.mycompany.vendingmachine.dto.Item;
import java.math.BigDecimal;
import java.util.List;
import org.junit.After;
import org.junit.AfterClass;
import static org.junit.Assert.assertEquals;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Test;

/**
 *
 * @author n0200797
 */
public class VendingMachineServiceLayerTest {
    
    private VendingMachineServiceLayer service;
    
    public VendingMachineServiceLayerTest() {
        VendingMachineDao dao = new VendingMachineDaoStubImpl();//To USE the STUB IMPLEMENTATION
        service = new VendingMachineServiceLayerImpl(dao);
    }
//******************************************************************************    
    //Static
    @BeforeClass
    public static void setUpClass() {
    }
    
    @AfterClass
    public static void tearDownClass() {
    }
    
    @Before
    public void setUp() {
    }
    
    @After
    public void tearDown() {
    }
//******************************************************************************
    /**
     * Test of getInventory method, of class VendingMachineServiceLayer.
     */
    @Test
    public void testGetInventory() throws Exception {
        System.out.println("GET INVENTORY TEST");
        assertEquals(1, service.getInventory().size());
    }

    /**
     * Test of validateMoney method, of class VendingMachineServiceLayer.
     */
    @Test
    public void testValidateMoney() throws Exception {
        System.out.println("VALIDATE MONEY RULES");
        BigDecimal clientMoney = new BigDecimal("1.05");
        service.validateMoney(clientMoney);
    }

    /**
     * Test of purchaseItem method, of class VendingMachineServiceLayer.
     */
    @Test
    public void testPurchaseItem() throws Exception {
        
    }

    /**
     * Test of saveInventory method, of class VendingMachineServiceLayer.
     */
    @Test
    public void testSaveInventory() throws Exception {
        System.out.println("SAVE INVENTORY");
    }

    
}
